#!/usr/bin/env bash
printf '%s\n' "$*" >> "$TRIVY_CALLS_PATH"
